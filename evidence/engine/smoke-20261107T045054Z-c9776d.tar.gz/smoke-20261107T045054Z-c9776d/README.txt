Agent Fire Drill evidence bundle smoke-20261107T045054Z-c9776d
Protocol refill-v1 (sha256 fde37ddf5854984c847928dab12dcd30381a2b6f796410dffaedba52b7710ddb).
Verify integrity:  sha256sum -c MANIFEST.sha256   (or: python3 -m afd.bundle verify <this dir>)
verdict.json is a pure function of protocol.json, plan.json, runs.jsonl, selftest.json and teardown.json (afd/qualify.py:verdict).
Scores come from backend state (refills_remaining and the effect ledger), never from the agent's claims.
